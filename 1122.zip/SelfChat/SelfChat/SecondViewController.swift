//
//  SecondViewController.swift
//  SelfChat
//
//  Created by NDHU_CSIE on 2021/11/22.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet var InputText: UITextField!
    @IBOutlet var OutputText: UILabel!
    
    var received: String?

    override func viewDidLoad() {
        super.viewDidLoad()

        OutputText.text = received
    }
    
}
