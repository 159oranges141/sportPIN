//
//  ViewController.swift
//  SelfChat
//
//  Created by NDHU_CSIE on 2021/11/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var InputText: UITextField!
    @IBOutlet var OutputText: UILabel!
    
    var received: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ChangeUser" {
            //pass the data
            let des =  segue.destination as! SecondViewController
            des.received = InputText.text
        }
    }
    
    @IBAction func backto(segue: UIStoryboardSegue){
        let src = segue.source as! SecondViewController
        received = src.InputText.text
        OutputText.text = received
        //close the source (second) view controller
        dismiss(animated: true, completion: nil)
    }
}

