//
//  TraceMapViewController.swift
//  LocationAPPStarter
//
//  Created by 羅壽之 on 2021/11/28.
//

import UIKit
import MapKit

class TraceMapViewController: UIViewController {
    
    @IBOutlet var mapView: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Requests the user’s permission to use location services
        // Set the desired accuracy (optionally)
        
        // Set the visible region
     
        // Enable the display of the user's current location
        
        // Set the delegate
        
    }
    
    // Implement the response method for location updates in the MKMapViewDelegate protocol
    

   
}
